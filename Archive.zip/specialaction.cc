#include "specialaction.h"

SpecialAction::~SpecialAction(){}